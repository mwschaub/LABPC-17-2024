﻿using System;
using System.Collections;
using System.Collections.Generic;
namespace Proyecto2b
//Marc Wilhelm Schaub Garcia 1243424
{
    class Proyecto2b_Main
    {
        // Inicio del programa declarando el método principal

    public double saldocuenta = 2500.0;
    public int conteodeposito = 0;
        static void Main(String[] args)
        {
            //declaracion de variables a usar
            int conta=0;
            double saldo=2500;
            double pos=0;
            double tasaInt = 0.02;
            int diasM= 30;
            int diasT= 0;
            //programación defensiva para los datos ingresados por el usuario
            Console.WriteLine("Ingrese su tipo de cuenta");
#pragma warning disable CS8600 // Converting null literal or possible null value to non-nullable type.
            String cuenta = Console.ReadLine();
#pragma warning restore CS8600 // Converting null literal or possible null value to non-nullable type.
            Console.WriteLine("Ingrese su nombre");
#pragma warning disable CS8600 // Converting null literal or possible null value to non-nullable type.
            string nombre = Console.ReadLine();
#pragma warning restore CS8600 // Converting null literal or possible null value to non-nullable type.
            Console.WriteLine("Ingrese su dpi");
            string dpi = Console.ReadLine();
             if (dpi.Length == 5 && int.TryParse(dpi, out int result))
        {
            Console.WriteLine("El DPI es válido.");
        }
        else
        {
            Console.WriteLine("El DPI no es válido.");
        }
            Console.WriteLine("Ingrese su Dirección");
            string Direccion = Console.ReadLine();
            Console.WriteLine("Ingrese su numero de telefono");
            int tel = int.Parse (Console.ReadLine());
            bool salir = false;
            while(!salir)
            {
                Console.WriteLine("╔═══════════════════════════════════════════════════════════╗");
                Console.WriteLine("║                          * MENÚ *                         ║");
                Console.WriteLine("╠══════════════════════════════╦════════════════════════════╣");
                Console.WriteLine("║  1. Informacion  de cuenta   ║  2. Comprar producto       ║");
                Console.WriteLine("╠══════════════════════════════╬════════════════════════════╣");
                Console.WriteLine("║   3. Vender producto         ║   4. Abonar cuenta         ║");
                Console.WriteLine("╠══════════════════════════════╬════════════════════════════╣");
                Console.WriteLine("║    5. Simular tiempo         ║ 6.Registro de transacciones║");
                Console.WriteLine("╠══════════════════════════════╬════════════════════════════╣");
                Console.WriteLine("║  7. Mantenimiento de cuentas ║   8. Transferir a otros    ║");
                Console.WriteLine("╠══════════════════════════════╬════════════════════════════╣");
                Console.WriteLine("║    9. Pago de servicios      ║10. Imprimir transacciones  ║");
                Console.WriteLine("╠══════════════════════════════╚════════════════════════════╣");
                Console.WriteLine("║                        11. Salir                          ║");
                Console.WriteLine("╚═══════════════════════════════════════════════════════════╝");
                Console.Write("Selecciona la opcion a seguir:");

                string opcion = Console.ReadLine();
                switch(opcion)
                {
                    case "1":
                    Console.WriteLine("Su nombre es " + nombre + ", su tipo de cuenta es " + cuenta + ", su dpi es " + dpi + ", su direccion es " + Direccion + ", su saldo es " + saldo + ", y su telefono es " + tel);
                    break;
                    case "2":
                    saldo = saldo - (saldo * 0.10);
                    Console.WriteLine("Su saldo actual es " + saldo);
                    break;
                    case "3":
                    pos=saldo*0.11;
                    if (saldo < 500)
                    {Console.WriteLine("Error, el saldo es muy bajo, su saldo actual es de " + saldo);}
                    else
                    {saldo = saldo + (saldo * 0.11);
                    Console.WriteLine("Su saldo actual es " + saldo + ", la ganancia fue de " + pos);}
                    break;
                    case"4":
                    if (saldo < 500)
                    {
                    if (conta < 2)
                    {
                        saldo=saldo*2;
                        Console.WriteLine("Tu nuevo saldo es de "+ saldo);
                    }
                    else {Console.WriteLine("Esta accion no se puede repetir mas de 2 veces");}
                    conta=conta+1;
                    }
                    else {Console.WriteLine("Error, su saldo es demasiado alto");}
                    break;
                    case "5":
                     Console.WriteLine("Seleccione el periodo de capitalización:");
                     Console.WriteLine("1. Una vez al mes");
                     Console.WriteLine("2. Dos veces al mes");
                     int periodoCap = Convert.ToInt32(Console.ReadLine());
                     if (periodoCap == 1)
                    {
                    while (diasT < diasM)
                    {
                        double interes = saldo * tasaInt * (diasT + 1)/360;
                        saldo += interes;
                        diasT++;
                        if (periodoCap == 1 && diasT == 30) 
                        {
                            Console.WriteLine($"Día 30: Saldo bancario (actualizado) = {saldo:C}");
                        }
                    }
                    }
                    if (periodoCap == 2)
                    {
                    while (diasT < diasM/2)
                    {
                        double interes = saldo * tasaInt * (diasT + 1)/360;
                        saldo += interes;
                        diasT++;
                        
                        if (periodoCap == 2 && diasT == 15)
                        {
                        interes = saldo * tasaInt * (diasT)/360;
                        saldo += interes;
                        Console.WriteLine($"Día 15: Saldo bancario (actualizado) = {saldo:C}");
                        }
                    }
                    }
                    break;
                    case "6":
                    Transacciones_varias.RegistroTransacciones();
                    break;
                    case "7":
                    Transacciones_varias.MantenimientoTerceros();
                    break;
                    case "8":
                    Transacciones_varias.TransferenciasOtrasCuentas();
                    break;
                    case "9":
                    Transacciones_varias.PagoServicios();
                    break;
                    case "10":
                    Transacciones_varias.InformeTransacciones();
                    break;
                    //salir
                    case "11":
                    Console.WriteLine("Has elegido salir de la aplicacion");
                    salir = true;
                    break;
                    default:
                Console.WriteLine("La opcion seleccionada no es valida");
                break;
                }
            }
        }
    }
    //clase con las demás transacciones
    public class Transacciones_varias
    {
     public transaccion[] transacciones1;
    public cuentade3ero[] cuentasTerceros1;
    public int transaccioncont;
    public int cuentaTerceroCont;
    private decimal saldo;

    public Transacciones_varias()
    {
        transacciones1 = new transaccion[100];
        cuentasTerceros1 = new cuentade3ero[100];
        transaccioncont = 0;
        cuentaTerceroCont = 0;
        saldo = 0;
    }
    public static void RegistrarTransaccion(DateTime fecha, decimal monto, string tipot)
      {
     if (transaccioncont < transacciones1.Length)
        {
            transacciones1[transaccioncont] = new transaccion
            {
                fechatrans = fecha,
                montotrans = monto,
                tipo = tipot
            };
            transaccioncont++;
        }
        else
        {
            Console.WriteLine("No se permiten mas transacciones");
        }
    }
        public static void MantenimientoTerceros(string propietariocuenta, string numerocuenta, string nombrebanco, decimal montotransferido, string moneda)
    {
        cuentade3ero nuevaCuenta = new cuentade3ero
        {
            ncuenta = cuentade3ero.Count + 1,
            propietariocuenta = propietariocuenta,
            numerocuenta = numerocuenta,
            nombrebanco = nombrebanco,
            montotransferido = montotransferido,
            moneda = moneda
        };
        
        cuentade3ero.Insert(cuentade3ero.Count, nuevaCuenta);
        RegistrarTransaccion(DateTime.Now, montotransferido, "Débito");
        saldoactual -= montotransferido;
    }
        public static void TransferenciasOtrasCuentas(int ncuenta, decimal monto)
    {
           for (int i = 0; i < cuentade3ero.Count; i++)
        {
            if (cuentade3ero[i].Id == ncuenta && (monto == 200 || monto == 2000))
            {
                RegistrarTransaccion(DateTime.Now, monto, $"Transferencia a {cuentade3ero[i].NumeroCuenta}");
                saldocuenta -= monto;
                return;
            }
        }
        Console.WriteLine("monto o cuenta no válido");
    }
    }
        public void PagoServicios(string proveedor, decimal monto)
    {
           if (saldocuenta >= monto)
        {
            RegistrarTransaccion(DateTime.Now, monto, $"Pago a {proveedor}");
            saldocuenta -= monto;
        }
        else
        {
            Console.WriteLine("Saldo insuficiente para realizar el pago.");
        }
    }
        public static void InformeTransacciones()
    {
        foreach (var transaccion in transaccion)
        {
            Console.WriteLine($"{transaccion.Date} , {transaccion.Type} , {transaccion.Amount:C}");
        }
    }
}

//constructores para funciones
public class transaccion
{
    public DateTime fechatrans { get; set; }
    public decimal montotrans { get; set; }
    public string tipo { get; set; }
}

public class cuentade3ero
{
    internal string moneda;

    public static int cont { get; internal set; }
    public int ncuenta { get; set; }
    public string propietariocuenta { get; set; }
    public string numerocuenta { get; set; }
    public string nombrebanco { get; set; }
    public decimal montotransferido { get; set; }
    public string saldoactual { get; set; }
}

