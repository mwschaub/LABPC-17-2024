﻿namespace  proyecto1
{
    class Proyecto {

static void Main(String[] args){

    int contames = 0;
    double saldo=2500;
    // if case 4
    if (saldo<500 || contames<=1){
        saldo = saldo * 2;
        contames = contames + 1;
        Console.ReadLine("Proceso realizado correctamente");
        Console.ReadLine("El saldo actual es: Q."+saldo);
    }
    else {
        Console.WriteLine("El saldo no es menor a 500 o ya realizó esta acción dos veces en el mes");
    }
}
}
}