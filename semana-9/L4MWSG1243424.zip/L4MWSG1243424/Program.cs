﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
// Marc Schaub
// 1243424
//Fibonacci en consola
namespace Semana9fibonacci
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int num;
            Console.WriteLine("Ingrese el numero");
            num = Convert.ToInt32(Console.ReadLine());
            int a = 0;
            int b = 1;
            int c = 0;
            int i = 2;
            string res = "";
            if (num > 0) {
                res += a;
                if (num > 1)
                {
                    res += ", "+b;
                    while (i < num)
                    {
                        c = a + b;
                        res += " , "+ c;
                        a = b;
                        b = c;
                        i = i + 1;
                    }
                    Console.WriteLine("el resultado obtenido es: " + res);

                }
                else {
                    Console.WriteLine("el resultado obtenido es: "+res);
                    return;
                }
            }
        }
    }
}
